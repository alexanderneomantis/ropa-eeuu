export const config = {
  dataset: 'production',
  projectId: 'r7cw8yij',
  apiVersion: '2022-06-5',
  useCnd: 'production'
}
