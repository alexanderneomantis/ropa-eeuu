export default function ComingSoon() {
  return (
    <div>hello world from ComingSoon</div>
  )
}
