export { default as PageNotFoundIllustration } from './illustration_404';
